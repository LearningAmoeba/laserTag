var express = require("express");
var myParser = require("body-parser");
var app = express();

  app.use(myParser.json({extended : true}));

  app.post("/registeruser", function(request, response) {
       saveRegistrationData(request); //This is what happens when a POST request is sent to /registeruser
 });
app.listen(8080);
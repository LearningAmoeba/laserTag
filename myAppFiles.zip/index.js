const http = require('http');
const url = require("url");
var uName1;
var uName2;
var uName1C;
var uName2C;
var redScore = 100;
var greenScore = 100;

const server = http.createServer((request, response) => {
    var query;
    query = url.parse(request.url, true).query;
    response.writeHead(200, {'Content-Type': 'text/plain'})
    if(query.inp == 'state'){
        response.write(`${uName1} :Score: ${redScore}, ${uName2} :Score: ${greenScore}`);
    }
    if (query.inp.substring(0,4) == 'user') {
        if (uName1 == undefined) {
            uName1 = query.inp.substring(4, query.inp.length);
            uName1C = 'red';
            response.write(`User1: ${uName1}`);
        }

        else {
            uName2 = query.inp.substring(4, query.inp.length);
            uName2C = 'green';
            //response.write(`We have recieved a second value, ${inp2}.&lt;/h1&gt;
            //We currently have values ${inp1} and ${inp2} stored`);
            response.write(`User1: ${uName1} User2: ${uName2}`);
        }
    }
    if (query.inp.substring(0,2) == 'up') {
        var temp = query.inp.substring;
        var parsed = temp.split('0');
        var colorHit = parsed[1];
        if (colorHit == 'red'){
            redScore = redScore -10;
        }
        if (colorHit == 'green'){
            greenScore = greenScore - 10;
        }
    }
    /*if (numRecieved > 2) {
        response.write(`We currently have values ${uName1} and ${uName2} stored`);
    }
    */
    
    response.end();
});

const port = process.env.PORT || 1337;
server.listen(port);
console.log("Server running at http://localhost:%d", port);



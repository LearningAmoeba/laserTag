const http = require('http');
const url = require("url");
var numRecieved = 0;
var inp1;
var inp2;

const server = http.createServer((request, response) => {
    var query, input;
    query = url.parse(request.url, true).query;
    response.writeHead(200, {"Content-Type": "text/html"});
    
    if (numRecieved == 0){
    inp1 = query.inp;
    response.write(`We have recieved the value ${inp1}.&lt;/h1&gt;`);
    numRecieved++;
    }
    else if (numRecieved == 1) {
        inp2 = query.inp;
        response.write(`We have recieved a second value, ${inp2}.&lt;/h1&gt;
        We currently have values ${inp1} and ${inp2} stored`);
        numRecieved++;
    }

    else {
        response.write(`Storage at capacity;
        We currently have values ${inp1} and ${inp2} stored`);
    }
    
    response.end();
});

const port = process.env.PORT || 1337;
server.listen(port);

console.log("Server running at http://localhost:%d", port);


